import tkinter as tk
from tkinter import *

root = tk.Tk()
root.title('twitter')

#iconbitmap() method is used to set the icon in a GUI window.
root.iconbitmap(r'C:\Users\hp\OneDrive\Desktop\Python tkinter projects\twitter.png')

root.mainloop()